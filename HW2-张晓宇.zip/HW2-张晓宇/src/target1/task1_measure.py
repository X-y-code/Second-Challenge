import json
import time
import random
import requests
import numpy as np
from datetime import datetime

# ============ 配置 ============
SERVER_URL = "http://127.0.0.1:30000"
GENERATE_URL = f"{SERVER_URL}/generate"
FLUSH_URL = f"{SERVER_URL}/flush_cache"

SHARED_PREFIX_LEN = 2048
SUFFIX_LEN = 64
NUM_REQUESTS = 32
MAX_CONCURRENCY = 8
MAX_NEW_TOKENS = 16
SEED = 2026

random.seed(SEED)

# ============ 构造 input_ids ============
shared_prefix = [random.randint(0, 10000) for _ in range(SHARED_PREFIX_LEN)]

shared_prefix_inputs = []
for i in range(NUM_REQUESTS):
    suffix = [random.randint(0, 10000) for _ in range(SUFFIX_LEN)]
    shared_prefix_inputs.append(shared_prefix + suffix)

dispersed_prefix_inputs = []
for i in range(NUM_REQUESTS):
    dispersed_prefix_inputs.append([random.randint(0, 10000) for _ in range(SHARED_PREFIX_LEN + SUFFIX_LEN)])

# ============ 通用请求函数 ============
def send_generate(input_ids, stream=True):
    payload = {
        "input_ids": input_ids,
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SEED,
        },
        "stream": stream,
    }

    t0 = time.time()
    ttft = None
    last_time = None
    cached_tokens = 0
    prompt_tokens = len(input_ids)
    completion_tokens = 0
    status = None

    try:
        with requests.post(GENERATE_URL, json=payload, stream=stream, timeout=120) as r:
            status = r.status_code
            if stream:
                for line in r.iter_lines():
                    if not line:
                        continue
                    line = line.decode("utf-8").strip()
                    if line.startswith("data: "):
                        line = line[6:]
                    if line == "[DONE]":
                        break
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if ttft is None:
                        ttft = time.time() - t0

                    meta = data.get("meta_info", {})
                    if "cached_tokens" in meta:
                        cached_tokens = meta["cached_tokens"]
                    if "completion_tokens" in meta:
                        completion_tokens = meta["completion_tokens"]

                    last_time = time.time()
            else:
                data = r.json()
                ttft = time.time() - t0
                last_time = ttft
                meta = data.get("meta_info", {})
                cached_tokens = meta.get("cached_tokens", 0)
                completion_tokens = meta.get("completion_tokens", 0)

    except Exception as e:
        status = "ERROR"
        print(f"请求失败: {e}")

    latency = (last_time - t0) if last_time else None
    tpot = ((latency - ttft) / (completion_tokens - 1)) if (latency and ttft and completion_tokens > 1) else None

    return {
        "prompt_tokens": prompt_tokens,
        "cached_tokens": cached_tokens,
        "completion_tokens": completion_tokens,
        "status": status,
        "ttft": ttft,
        "latency": latency,
        "tpot": tpot,
    }


def flush_cache():
    try:
        r = requests.post(FLUSH_URL, timeout=30)
        return r.status_code == 200
    except Exception as e:
        print(f"flush_cache 失败: {e}")
        return False


def run_group(name, input_list, warmup=False):
    print(f"\n{'='*60}")
    print(f"开始实验组：{name}")
    print(f"{'='*60}")

    time.sleep(2)
    ok = flush_cache()
    print(f"flush_cache: {'成功' if ok else '失败'}")
    time.sleep(1)

    if warmup:
        print("发送预热请求（不计入结果）...")
        send_generate(input_list[0])
        time.sleep(1)

    results = []
    for i, input_ids in enumerate(input_list):
        r = send_generate(input_ids)
        results.append(r)
        print(f"[{name}] req {i+1}/{len(input_list)}  "
              f"status={r['status']}  cached={r['cached_tokens']}  "
              f"ttft={r['ttft']:.3f}s  latency={r['latency']:.3f}s")

    summary = {
        "name": name,
        "total_requests": len(results),
        "success": sum(1 for r in results if r["status"] == 200),
        "total_prompt_tokens": sum(r["prompt_tokens"] for r in results),
        "total_cached_tokens": sum(r["cached_tokens"] for r in results),
        "total_completion_tokens": sum(r["completion_tokens"] for r in results),
    }
    summary["cache_hit_rate"] = summary["total_cached_tokens"] / summary["total_prompt_tokens"]
    summary["actual_prefill_tokens"] = summary["total_prompt_tokens"] - summary["total_cached_tokens"]

    ttfts = [r["ttft"] for r in results if r["ttft"]]
    latencies = [r["latency"] for r in results if r["latency"]]
    tpots = [r["tpot"] for r in results if r["tpot"]]

    for label, values in [("ttft", ttfts), ("latency", latencies), ("tpot", tpots)]:
        if values:
            summary[f"{label}_p50"] = float(np.percentile(values, 50))
            summary[f"{label}_p95"] = float(np.percentile(values, 95))

    return summary, results


# ============ 主流程 ============
if __name__ == "__main__":
    print("服务预热中...")
    send_generate([random.randint(0, 10000) for _ in range(10)])
    time.sleep(2)

    summary_shared, results_shared = run_group(
        "shared_prefix", shared_prefix_inputs, warmup=True
    )

    summary_dispersed, results_dispersed = run_group(
        "dispersed_prefix", dispersed_prefix_inputs, warmup=False
    )

    output = {
        "timestamp": datetime.now().isoformat(),
        "shared_prefix": {"summary": summary_shared, "details": results_shared},
        "dispersed_prefix": {"summary": summary_dispersed, "details": results_dispersed},
    }

    with open("task1_results.json", "w") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("\n" + "="*60)
    print("对照表")
    print("="*60)
    print(f"{'指标':<30} {'共享前缀组':<20} {'分散前缀组':<20}")
    print("-"*70)
    print(f"{'成功率':<30} {summary_shared['success']}/32{'':<15} {summary_dispersed['success']}/32")
    print(f"{'缓存命中率':<30} {summary_shared['cache_hit_rate']:.2%}{'':<15} {summary_dispersed['cache_hit_rate']:.2%}")
    print(f"{'实际 Prefill token 数':<30} {summary_shared['actual_prefill_tokens']}{'':<15} {summary_dispersed['actual_prefill_tokens']}")
    print(f"{'TTFT p50 (s)':<30} {summary_shared.get('ttft_p50', 0):.4f}{'':<15} {summary_dispersed.get('ttft_p50', 0):.4f}")
    print(f"{'TTFT p95 (s)':<30} {summary_shared.get('ttft_p95', 0):.4f}{'':<15} {summary_dispersed.get('ttft_p95', 0):.4f}")
    print(f"{'TPOT p50 (s)':<30} {summary_shared.get('tpot_p50', 0):.4f}{'':<15} {summary_dispersed.get('tpot_p50', 0):.4f}")
    print(f"{'端到端 p50 (s)':<30} {summary_shared.get('latency_p50', 0):.4f}{'':<15} {summary_dispersed.get('latency_p50', 0):.4f}")
